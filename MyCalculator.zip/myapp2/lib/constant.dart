import 'package:flutter/material.dart';

const Color Blue = Colors.red;
const Color Green = Colors.red;
const TextStyle1 =
    TextStyle(fontSize: 30, color: Colors.green, fontWeight: FontWeight.bold);
const text2 = TextStyle(fontWeight: FontWeight.bold, fontSize: 24);
