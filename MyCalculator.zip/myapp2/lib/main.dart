import 'package:flutter/material.dart';
import 'package:math_expressions/math_expressions.dart';
import 'package:myapp2/userBuiltFuction.dart';

void main() {
  print('hello');
  return runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  var userInput = '';
  var answer = '';
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 60),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 20),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            userInput.toString(),
                            style: TextStyle(
                                fontSize: 30, color: Colors.lightBlue),
                          ),
                          Text(
                            answer.toString(),
                            style: TextStyle(
                                fontSize: 30, color: Colors.lightBlue),
                          ),
                        ],
                      ),
                    ),
                  ),

                  // buttons
                  Expanded(
                    flex: 3,
                    child: Column(
                      children: [
                        Row(
                          children: [
                            myButton(
                              symbol: "AC",
                              onPress: () {
                                userInput = '';
                                answer = '';
                                setState(() {});
                              },
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            myButton(
                              symbol: "+/-",
                              onPress: () {
                                userInput += '+/-';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "%",
                              onPress: () {
                                userInput += '%';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "/",
                              color: Colors.orange,
                              onPress: () {
                                userInput += '/';
                                setState(() {});
                              },
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            myButton(
                              symbol: "7",
                              onPress: () {
                                userInput += '7';
                                setState(() {});
                              },
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            myButton(
                              symbol: "8",
                              onPress: () {
                                userInput += '8';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "9",
                              onPress: () {
                                userInput += '9';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "x",
                              color: Colors.orange,
                              onPress: () {
                                userInput += '*';
                                setState(() {});
                              },
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            myButton(
                              symbol: "4",
                              onPress: () {
                                userInput += '4';
                                setState(() {});
                              },
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            myButton(
                              symbol: "5",
                              onPress: () {
                                userInput += '5';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "6",
                              onPress: () {
                                userInput += '6';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "-",
                              color: Colors.orange,
                              onPress: () {
                                userInput += '-';
                                setState(() {});
                              },
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            myButton(
                              symbol: "1",
                              onPress: () {
                                userInput += '1';
                                setState(() {});
                              },
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            myButton(
                              symbol: "2",
                              onPress: () {
                                userInput += '2';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "3",
                              onPress: () {
                                userInput += '3';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "+",
                              color: Colors.orange,
                              onPress: () {
                                userInput += '+';
                                setState(() {});
                              },
                            ),
                          ],
                        ),
                        Row(
                          children: [
                            myButton(
                              symbol: "0",
                              onPress: () {
                                userInput += '0';
                                setState(() {});
                              },
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            myButton(
                              symbol: ".",
                              onPress: () {
                                userInput += '.';
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "DEL",
                              onPress: () {
                                userInput = userInput.substring(
                                    0, userInput.length - 1);
                                setState(() {});
                              },
                            ),
                            myButton(
                              symbol: "=",
                              color: Colors.orange,
                              onPress: () {
                                equalPress();
                                setState(() {});
                              },
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void equalPress() {
    Parser p = Parser();
    Expression exp = p.parse(userInput);
    ContextModel contextModel = ContextModel();
    double eval = exp.evaluate(EvaluationType.REAL, contextModel);
    answer = eval.toString();
  }
}
